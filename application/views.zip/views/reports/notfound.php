<style>
.center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  min-height: 100vh;
}
</style>
<div class="center-screen">
<div><img src="<?=base_url('public/assets/images/ic_notfund.gif')?>" style="width:30%"></div>
</div>