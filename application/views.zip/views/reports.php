<div class="row">
    <div class="col-md-2 col-sm-6 col-12 kb-search-content">
        <div class="card">
            <a href="<?=base_url('reports/report/1')?>">
                <img src="<?=base_url('public')?>/app-assets/images/illustration/api.svg" class="card-img-top" alt="knowledge-base-image" />
                <div class="card-body text-center">
                    <h3>List Of Users</h3>
                    <p class="text-body mt-1 mb-0">Users List Report</p>
                </div>
            </a>
        </div>
    </div>

    <div class="col-md-2 col-sm-6 col-12 kb-search-content">
        <div class="card">
            <a href="<?=base_url('reports/report/2')?>">
                <img src="<?=base_url('public')?>/app-assets/images/illustration/api.svg" class="card-img-top" alt="knowledge-base-image" />
                <div class="card-body text-center">
                    <h3>Wife Sessions List</h3>
                    <p class="text-body mt-1 mb-0">List Of Wife Sessions</p>
                </div>
            </a>
        </div>
    </div>
    
</div>