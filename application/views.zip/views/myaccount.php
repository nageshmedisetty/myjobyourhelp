
						
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="row">
								<div class="col-md-12">
									<div>
										<div>
											<div class="row">
												<div class="col-md-12 col-lg-5" style="text-align: center;background-color: #fd8700;padding: 10px;margin: 6px;">
													<div>
														<div>
															<h4 style="color: white;">Opened Help requests </h4>
															<h3 style="font-size: 7.5rem;">10</h3>
														</div>
													</div>
												</div>
												
												<div class="col-md-12 col-lg-5" style="text-align: center;background-color: #00fd3d;padding: 10px;margin: 6px;">
													<div>
														<div>
															<h4 style="color: white;">Served Help Requests </h4>
															<h3 style="font-size: 7.5rem;">16</h3>
														</div>
													</div>
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		