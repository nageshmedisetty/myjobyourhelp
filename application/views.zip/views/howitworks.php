<div class="breadcrumb-bar" style="padding-left:5px;padding-right:5px;">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-12 col-12">
                <nav aria-label="breadcrumb" class="page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?=base_url('')?>"><?=$home?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?=$dashboard?></li>
                    </ol>
                </nav>
                <h2 class="breadcrumb-title"><?=$dashboard?></h2>
            </div>
        </div>
    </div>
</div>

<!-- Page Content -->
<div class="row">
								<div class="col-md-8">
									<div class="card dash-card" style="background-color: #ffffff;">
										<div class="card-body">
											<div class="row">
												<img src="<?=$assets?>images/MJ.png" style="width: 100%;">
												
												
												
												
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="card dash-card" style="background-color: #ffffff;">
										<div class="card-body">
											<div class="row" style="margin: 5%;">
												<h3>How it Works</h3>
												<p>Step1: Help Requester Fill Help Request Form<br>
Step2: Request will move to Open Help Requests Pool<br>
Step3: Help Providers responds to Help Request<br>
Step4: Help Requester selects Help Provider and connect via Phone/Email/WhatsApp<br>
Step5: Request will move to In-Progress Requests Pool<br>
Step6: Un-Assign current Help Provider to assign new Help Provider if required<br>
Step7: Close the Help Request if the task is complete<br>
Step8: Help Requester write review on Help Provider & Help Provider write review on Help Requester</p>
												
												
											</div>
										</div>
									</div>
								</div>
							</div>
			<!-- /Page Content -->
